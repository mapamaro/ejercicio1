package co.edu.unbosque.ciclo3demo;
import java.sql.*;

public class conector {
String nombreBd = "tiendagenerica";
String usuario = "admin";
String contrase�a ="admin";
String url="jdbc:mysql://localhost:3306/nombreBd";

Connection con= null;
	public conector conector() {
			    
	    
	        try{
	            Class.forName("com.mysql.jdbc.Driver");
	            con=DriverManager.getConnection(url,usuario,contrase�a);
	            
	        }catch(Exception e){
	            e.printStackTrace();
	        }
	        return (conector) con;
	    }
	}

