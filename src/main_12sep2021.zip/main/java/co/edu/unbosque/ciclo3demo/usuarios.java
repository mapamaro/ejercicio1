package co.edu.unbosque.ciclo3demo;

public class usuarios {
String cedula;
String usuario;
String nombre;
String contrase�a;
String email;

	public String getCedula() {
	return cedula;
}

public void setCedula(String cedula) {
	this.cedula = cedula;
}

public String getUsuario() {
	return usuario;
}

public void setUsuario(String usuario) {
	this.usuario = usuario;
}

public String getNombre() {
	return nombre;
}

public void setNombre(String nombre) {
	this.nombre = nombre;
}

public String getContrase�a() {
	return contrase�a;
}

public void setContrase�a(String contrase�a) {
	this.contrase�a = contrase�a;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

	public usuarios() {
	this.cedula = "";
	this.usuario = "";
	this.nombre = "";
	this.contrase�a = "";
	this.email = "";
	}

}
